library(tidyverse)

users <- read_csv(
  "hadley_guido_users.csv",
  col_types = "ccliiiiiTlccccccccccTTTdddd"  # treat user ids as character
)

follows <- read_csv(
  "hadley_guido_edges.csv",
  col_types = "cc"  #  treat user ids as character
)

# install.packages("tidygraph")
library(tidygraph)

graph <- tbl_graph(edges = follows) %>% 
  left_join(users, by = c("name" = "user_id"))

graph

# remotes::install_github("RoheLab/vsp")
library(vsp)
library(tidytext)
library(Matrix)

# this is a hack where i discard some users without descriptions because
# getting a user x description word matrix when you have empty descriptions
# is a PITA


bio_words <- graph %>%
  as_tibble() %>% 
  filter(!is.na(description)) %>% 
  unnest_tweets(word, description) %>%
  cast_sparse(name, word)

graph_have_bio_words <- graph %>% 
  activate(nodes) %>% 
  filter(name %in% rownames(bio_words))

fa_desc <- vsp(graph_have_bio_words, rank = 10)
fa_desc

appearances <- colSums(bio_words)

freq_bio_words <- bio_words[, appearances > 5]

stopifnot(NROW(freq_bio_words) == NROW(fa_desc$Y))

y_keywords <- bff(fa_desc$Y, freq_bio_words, num_best = 10)
z_keywords <- bff(fa_desc$Z, freq_bio_words, num_best = 10)

y_factor_words <- y_keywords %>%
  mutate(
    id = colnames(fa$Y),
    words = pmap_chr(select(y_keywords, -factor), paste, sep = ", ")
  ) %>%
  select(factor, id, words)

y_factor_words

z_factor_words <- z_keywords %>%
  mutate(
    id = colnames(fa$Z),
    words = pmap_chr(select(z_keywords, -factor), paste, sep = ", ")
  ) %>%
  select(factor, id, words)

z_factor_words
